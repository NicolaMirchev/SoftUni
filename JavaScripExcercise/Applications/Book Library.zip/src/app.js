
import { logout } from "./api/api.js";
import { page, render } from "./lib.js";
import { updateNav } from "./util.js";
import { addBookPage } from "./views/addBook.js";
import { detailsPage } from "./views/details.js";
import { editPage } from "./views/edit.js";
import { dashboardPage } from "./views/home.js";
import { loginPage } from "./views/login.js";
import { myBooksPage } from "./views/myBooks.js";
import { registerPage } from "./views/register.js";






const root = document.querySelector('main');
page(decorateContext);
page('/', dashboardPage);
page('/login', loginPage);
page('/register', registerPage);
page('/logout', onLogout);
page('/addBook', addBookPage);
page('/details/:id', detailsPage);
page('/edit/:id', editPage);
page('/myBooks', myBooksPage);

page.start();


function decorateContext(ctx, next){

    ctx.render = (content) => render(content, root);

    next();    
}

async function onLogout(ctx){

    await logout();
    ctx.page.redirect('/');
    updateNav();

}