import { del,} from '../api/api.js';
import { html } from '../lib.js';
import { getBookById, getLikesById, getUserData, likeById, updateNav } from "../util.js";



const detailsTemplate = (book, isOwner, isUser, currentLikesNumber,onDelete , onLike) => html`
      <section id="details-page" class="details">
            <div class="book-information">
                <h3>${book.title}</h3>
                <p class="type">${book.type}</p>
                <p class="img"><img src="${book.imageUrl}"></p>
                <div class="actions">
                    <!-- Edit/Delete buttons ( Only for creator of this book )  -->

                    ${isOwner ? html`
                    <a class="button" href="/edit/${book._id}">Edit</a>
                    <a class="button" @click=${onDelete} href="#">Delete</a>`
                    : isUser ? html` <a class="button" @click=${onLike} href="#">Like</a> `
                             : null
                    }
                        <div class="likes">
                        <img class="hearts" src="/images/heart.png">
                        <span id="total-likes">Likes: ${currentLikesNumber}</span>
                    </div>

                </div>
            </div>
            <div class="book-description">
                <h3>Description:</h3>
                <p>${book.description}</p>
            </div>
        </section>`

export async function detailsPage(ctx){
    updateNav();

    const currentBookId = ctx.params['id'];
    const currentBook = await getBookById(currentBookId);

    const isOwner = getUserData() && getUserData().id == currentBook._ownerId;
    const isUser = getUserData();
    const currentLikesNumber = await getLikesById(currentBookId);
    console.log(currentLikesNumber);

    ctx.render(detailsTemplate(currentBook, isOwner, isUser, currentLikesNumber,onDelete, onLike));

    async function onDelete(event){
        event.preventDefault();

        const confirmM = confirm('Are you sure you want to delete this book?');

        if(confirmM){

            await del('/data/books/' + currentBookId);
            ctx.page.redirect('/');
        }
    }

    async function onLike(event){


       console.log(await likeById(currentBook));
       
    }


}