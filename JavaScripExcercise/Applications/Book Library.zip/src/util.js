import {  get, post  } from "./api/api.js";

export function setUserData(data){
    sessionStorage.setItem('userData', JSON.stringify(data));

    
}
export function getUserData(){
   return JSON.parse(sessionStorage.getItem('userData'));
}
export function clearUserData(){
    sessionStorage.removeItem('userData');
}


export async function getAllBooks(){
    return await get('/data/books?sortBy=_createdOn%20desc');
}

export async function getBookById(id){
    return get('/data/books/' + id);
}

export async function getLikesById(id){
    await get(`/data/likes?where=bookId%3D%22${id}%22&amp;distinct=_ownerId&amp;count`)
}

export async function likeById(id){

    await post('/data/likes', {bookId : id});
}


export function updateNav(){
    if(getUserData()){
        document.getElementById('guest').style.display = 'none';
        
        const userBar =  document.getElementById('user');
        userBar.style.display = 'block'
        document.querySelector('#user span').textContent = `Welcome, ${getUserData().email}`;

    }
    else {
        document.getElementById('guest').style.display = 'block';
        document.getElementById('user').style.display = 'none';
    }

}