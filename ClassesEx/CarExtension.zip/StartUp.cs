﻿using System;
using CarManufacturer;
 namespace CarManufacturer
{
    class StartUp
    {
        static void Main(string[] args)
        {

            Car car = new Car();
            car.FuelQuantity = 200;
            car.Make = "VW";
            car.Year = 2021;
            car.FuelConsumption = 11;
            car.Model = "Wagon";

            car.Drive(55);
            Console.WriteLine(car.WhoAmI());
        }
    }
}
